FCR 2017
========

Pacote do ROS para o curso de Fundamentos Computacionais de Robótica - CIC - UnB

* Pacote criado e testado no Ubuntu 14.04 e ROS Indigo

* Antes de usar o pacote instale o p2os-msgs:

$ sudo apt-get install ros-indigo-p2os-msgs
